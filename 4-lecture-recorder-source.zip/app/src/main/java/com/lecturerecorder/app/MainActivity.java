package com.lecturerecorder.app;
import android.app.*; import android.os.*; import android.content.*; import android.content.pm.PackageManager; import android.media.projection.*; import android.graphics.Color; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
    TextView state; Button start; Spinner mode,quality; final Handler timer=new Handler();
    final Runnable tick=new Runnable(){public void run(){refresh();timer.postDelayed(this,1000);}};
    int selectedMode; boolean notificationAsked=false;
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(24,44,47));t.setPadding(0,12,0,12);return t;}
    public void onCreate(Bundle b){super.onCreate(b);
        ScrollView sc=new ScrollView(this); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,40,28,28);root.setBackgroundColor(Color.rgb(247,248,244));sc.addView(root);setContentView(sc);
        root.addView(text("LECTURE RECORDER",14));root.addView(text("Screen + awaaz.\nSeedha phone mein.",30));
        root.addView(text("Android 10+  /  Free  /  Offline",15));
        state=text("Recording ke liye ready",17);root.addView(state);
        root.addView(text("Awaaz ka option",16));mode=new Spinner(this);mode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Internal audio (lecture)","Internal + mic (meri awaaz)","Sirf mic","Bina audio"}));root.addView(mode);
        root.addView(text("Video quality",16));quality=new Spinner(this);quality.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"HD 720p - kam storage","Full HD 1080p"}));root.addView(quality);
        start=new Button(this);start.setText("RECORDING SHURU KARO");start.setTextSize(17);start.setTextColor(Color.WHITE);start.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0,113,108)));root.addView(start,new LinearLayout.LayoutParams(-1,dp(60)));start.setOnClickListener(v->begin());
        Button stop=new Button(this);stop.setText("STOP AUR SAVE");root.addView(stop,new LinearLayout.LayoutParams(-1,dp(52)));stop.setOnClickListener(v->startService(new Intent(this,RecordingService.class).setAction("STOP")));
        Button open=new Button(this);open.setText("SAVED VIDEOS DEKHO");root.addView(open);open.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,"video/*"));}catch(Exception e){Toast.makeText(this,"Gallery > Movies > LectureRecorder dekho",Toast.LENGTH_LONG).show();}});
        root.addView(text("1. Shuru karo, phir Android ka Allow / Start now dabao.\n2. Lecture kholo. Stop notification se bhi kar sakte ho.\n3. MP4 Gallery / Movies / LectureRecorder mein milega.",15));
        root.addView(text("Pehle 10-second ka test karo: video aur awaaz dono check karo. Protected player black screen ya silent audio de sakta hai. Yeh app us protection ko nahi todta.\n\nNotifications / passwords bhi record ho sakte hain. DND on karo. Sirf permission wali class record karo. Phone charged rakho; force-close mat karo.",14));
    }
    public void onResume(){super.onResume();timer.post(tick);}public void onPause(){timer.removeCallbacks(tick);super.onPause();}
    void refresh(){state.setText(RecordingService.status);start.setEnabled(!RecordingService.busy);mode.setEnabled(!RecordingService.busy);quality.setEnabled(!RecordingService.busy);}
    void begin(){if(RecordingService.busy)return; selectedMode=mode.getSelectedItemPosition();
        if(selectedMode!=3&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},7);return;}
        if(!notificationAsked&&Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){notificationAsked=true;requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},8);return;}
        startActivityForResult(((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).createScreenCaptureIntent(),9);
    }
    public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==7&&(g.length==0||g[0]!=PackageManager.PERMISSION_GRANTED)){Toast.makeText(this,"Audio permission chahiye. Bina audio option bhi hai.",Toast.LENGTH_LONG).show();return;}if(r==7||r==8)begin();}
    public void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==9&&c==RESULT_OK&&data!=null){Intent i=new Intent(this,RecordingService.class).setAction("START").putExtra("code",c).putExtra("data",data).putExtra("mode",selectedMode).putExtra("cap",quality.getSelectedItemPosition()==0?1280:1920);startForegroundService(i);}}
}
