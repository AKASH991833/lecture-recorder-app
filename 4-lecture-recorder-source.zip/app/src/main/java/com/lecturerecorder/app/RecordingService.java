package com.lecturerecorder.app;

import android.app.*; import android.content.*; import android.content.pm.ServiceInfo; import android.hardware.display.*; import android.media.*; import android.media.projection.*; import android.os.*; import android.provider.MediaStore; import android.net.Uri; import android.graphics.Rect; import android.view.*; import android.util.DisplayMetrics;
import android.widget.Toast; import java.nio.*; import java.util.*; import java.util.concurrent.*; import java.text.SimpleDateFormat;

public class RecordingService extends Service {
    public static volatile boolean busy=false;
    public static volatile String status="Recording ke liye ready";
    volatile boolean stop=false; volatile Throwable failure;
    MediaProjection projection; VirtualDisplay display; MediaCodec video,audio; AudioRecord playback,mic;
    MediaMuxer muxer; ParcelFileDescriptor fd; Uri uri; Surface surface;
    int videoTrack=-1,audioTrack=-1; boolean muxStarted=false; int audioMode;
    long origin,startTime,bytesWritten; int sampleRate=48000; volatile long levelAt=0;
    final Object muxLock=new Object(); final ArrayList<Packet> pending=new ArrayList<>();
    Handler handler=new Handler(Looper.getMainLooper());
    static class Packet{byte[] bytes; int track;long pts;int flags;Packet(byte[] b,int t,long p,int f){bytes=b;track=t;pts=p;flags=f;}}
    public IBinder onBind(Intent i){return null;}
    Notification notice(String s){
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent finish=PendingIntent.getService(this,1,new Intent(this,RecordingService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,"recording").setSmallIcon(android.R.drawable.presence_video_online).setContentTitle("Lecture Recorder").setContentText(s).setContentIntent(open).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Stop aur save",finish).build();
    }
    public int onStartCommand(Intent intent,int flags,int id){
        if(intent==null){stopSelf();return START_NOT_STICKY;}
        if("STOP".equals(intent.getAction())){stop=true; if(busy)status="Save ho raha hai...";else stopSelf();return START_NOT_STICKY;}
        if(busy)return START_NOT_STICKY;
        busy=true;stop=false;status="Recording shuru ho rahi hai...";audioMode=intent.getIntExtra("mode",0);
        NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("recording","Screen recording",NotificationManager.IMPORTANCE_LOW));
        int types=ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
        if(Build.VERSION.SDK_INT>=30&&(audioMode==1||audioMode==2))types|=ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
        try{startForeground(21,notice("Recording shuru ho rahi hai"),types);}catch(Exception e){busy=false;status="Start nahi hua: "+e.getMessage();stopSelf();return START_NOT_STICKY;}
        new Thread(()->runRecording(intent),"recorder-controller").start();return START_NOT_STICKY;
    }
    void runRecording(Intent intent){
        try{
            projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(intent.getIntExtra("code",-1),intent.getParcelableExtra("data"));
            if(projection==null)throw new IllegalStateException("Screen permission nahi mila");
            projection.registerCallback(new MediaProjection.Callback(){public void onStop(){stop=true;}},handler);
            DisplayMetrics metrics=getResources().getDisplayMetrics();int w,h;
            WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
            if(Build.VERSION.SDK_INT>=30){Rect bounds=wm.getMaximumWindowMetrics().getBounds();w=bounds.width();h=bounds.height();}
            else{DisplayMetrics real=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(real);w=real.widthPixels;h=real.heightPixels;}
            int[] size=CaptureMath.fit(w,h,intent.getIntExtra("cap",1280));w=size[0];h=size[1];
            String name="Lecture_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";
            ContentValues cv=new ContentValues();cv.put(MediaStore.Video.Media.DISPLAY_NAME,name);cv.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");cv.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/LectureRecorder");cv.put(MediaStore.Video.Media.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,cv);if(uri==null)throw new IllegalStateException("Storage file nahi bana");
            fd=getContentResolver().openFileDescriptor(uri,"rw");if(fd==null)throw new IllegalStateException("Storage khul nahi raha");
            muxer=new MediaMuxer(fd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            MediaFormat vf=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,w,h);
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);vf.setInteger(MediaFormat.KEY_BIT_RATE,w*h>1000000?6000000:3500000);vf.setInteger(MediaFormat.KEY_FRAME_RATE,30);vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2);
            video=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);video.configure(vf,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);surface=video.createInputSurface();video.start();
            if(audioMode!=3)setupAudio();
            origin=System.nanoTime()/1000;startTime=System.currentTimeMillis();
            display=projection.createVirtualDisplay("LectureRecording",w,h,metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,surface,null,handler);
            Thread vt=new Thread(()->drainVideo(),"video-encoder");vt.start();
            Thread at=null;if(audioMode!=3){at=new Thread(()->recordAudio(),"audio-encoder");at.start();}
            handler.post(progress);
            while(!stop&&failure==null)Thread.sleep(100);
            stop=true; if(display!=null){display.release();display=null;}
            video.signalEndOfInputStream();
            vt.join(8000);if(at!=null)at.join(8000);
            if(vt.isAlive()||(at!=null&&at.isAlive()))throw new IllegalStateException("Encoder timeout; file incomplete");
            if(failure!=null)throw new Exception(failure);
            synchronized(muxLock){if(!muxStarted||bytesWritten==0)throw new IllegalStateException("Recording data nahi mila");muxer.stop();muxStarted=false;}
            ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(uri,done,null,null);
            status="Saved: Movies/LectureRecorder/"+name;uri=null;
        }catch(Throwable e){android.util.Log.e("LectureRecorder","record failed",e);status="Recording failed: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}
        finally{
            stop=true;handler.removeCallbacks(progress);release();
            if(uri!=null){try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}}
            busy=false;handler.post(()->{Toast.makeText(this,status,Toast.LENGTH_LONG).show();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();});
        }
    }
    void setupAudio() throws Exception{
        if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new SecurityException("Audio permission chahiye");
        int min=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);if(min<=0)throw new IllegalStateException("48k audio supported nahi hai");
        AudioFormat af=new AudioFormat.Builder().setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build();
        if(audioMode==0||audioMode==1){
            AudioPlaybackCaptureConfiguration config=new AudioPlaybackCaptureConfiguration.Builder(projection).addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME).addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build();
            playback=new AudioRecord.Builder().setAudioFormat(af).setBufferSizeInBytes(Math.max(min*4,16384)).setAudioPlaybackCaptureConfig(config).build();
            if(playback.getState()!=AudioRecord.STATE_INITIALIZED)throw new IllegalStateException("Internal audio initialize nahi hua");playback.startRecording();
        }
        if(audioMode==1||audioMode==2){mic=new AudioRecord.Builder().setAudioFormat(af).setBufferSizeInBytes(Math.max(min*4,16384)).setAudioSource(MediaRecorder.AudioSource.MIC).build();if(mic.getState()!=AudioRecord.STATE_INITIALIZED)throw new IllegalStateException("Mic available nahi hai");mic.startRecording();}
        MediaFormat a=MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,sampleRate,1);a.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC);a.setInteger(MediaFormat.KEY_BIT_RATE,128000);a.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,8192);
        audio=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);audio.configure(a,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);audio.start();
    }
    void drainVideo(){
        try{MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();long deadline=Long.MAX_VALUE;
            while(true){int ix=video.dequeueOutputBuffer(info,10000);
                if(ix==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED)addTrack(video.getOutputFormat(),true);
                else if(ix>=0){if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0)write(video.getOutputBuffer(ix),info,true);boolean eos=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;video.releaseOutputBuffer(ix,false);if(eos)break;}
                if(stop&&deadline==Long.MAX_VALUE)deadline=System.currentTimeMillis()+6500;
                if(System.currentTimeMillis()>deadline)throw new IllegalStateException("Video encoder did not finish");
            }
        }catch(Throwable e){failure=e;stop=true;}
    }
    void recordAudio(){
        try{short[] pcm=new short[1024],mpcm=new short[1024];long frames=0;long base=System.nanoTime()/1000-origin;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();boolean eosQueued=false,done=false;long deadline=Long.MAX_VALUE;
            while(!done){
                if(!eosQueued){int ix=audio.dequeueInputBuffer(10000);if(ix>=0){ByteBuffer input=audio.getInputBuffer(ix);input.clear();
                    if(stop){audio.queueInputBuffer(ix,0,0,base+CaptureMath.audioTime(frames,sampleRate),MediaCodec.BUFFER_FLAG_END_OF_STREAM);eosQueued=true;deadline=System.currentTimeMillis()+6000;}
                    else{int count=(playback!=null?playback:mic).read(pcm,0,pcm.length,AudioRecord.READ_BLOCKING);if(count<0)throw new IllegalStateException("Audio read error "+count);
                        if(playback!=null&&mic!=null){int mc=mic.read(mpcm,0,count,AudioRecord.READ_BLOCKING);if(mc<0)throw new IllegalStateException("Mic read error "+mc);for(int k=0;k<count;k++)pcm[k]=CaptureMath.mix(pcm[k],k<mc?mpcm[k]:0);}
                        for(int k=0;k<count;k++){input.order(ByteOrder.LITTLE_ENDIAN).putShort(pcm[k]);if(Math.abs((int)pcm[k])>180)levelAt=System.currentTimeMillis();}
                        audio.queueInputBuffer(ix,0,count*2,base+CaptureMath.audioTime(frames,sampleRate),0);frames+=count;
                    }
                }}
                int ix;while((ix=audio.dequeueOutputBuffer(info,1000))!=MediaCodec.INFO_TRY_AGAIN_LATER){if(ix==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED)addTrack(audio.getOutputFormat(),false);else if(ix>=0){if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0)write(audio.getOutputBuffer(ix),info,false);done=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;audio.releaseOutputBuffer(ix,false);if(done)break;}}
                if(System.currentTimeMillis()>deadline)throw new IllegalStateException("Audio encoder did not finish");
            }
        }catch(Throwable e){failure=e;stop=true;}
    }
    void addTrack(MediaFormat f,boolean isVideo){synchronized(muxLock){int t=muxer.addTrack(f);if(isVideo)videoTrack=t;else audioTrack=t;if(videoTrack>=0&&(audioMode==3||audioTrack>=0)){muxer.start();muxStarted=true;for(Packet p:pending)writePacket(p);pending.clear();}}}
    long lastVideo=-1,lastAudio=-1;
    void write(ByteBuffer b,MediaCodec.BufferInfo info,boolean isVideo){synchronized(muxLock){
        b.position(info.offset);b.limit(info.offset+info.size);byte[] data=new byte[info.size];b.get(data);
        long pts=isVideo?Math.max(0,info.presentationTimeUs-origin):Math.max(0,info.presentationTimeUs);
        if(isVideo){pts=Math.max(pts,lastVideo+1);lastVideo=pts;}else{pts=Math.max(pts,lastAudio+1);lastAudio=pts;}
        Packet p=new Packet(data,isVideo?videoTrack:audioTrack,pts,info.flags);
        if(muxStarted)writePacket(p);else{if(pending.size()>=300)throw new IllegalStateException("Audio/video format wait timeout");pending.add(p);}
    }}
    void writePacket(Packet p){MediaCodec.BufferInfo i=new MediaCodec.BufferInfo();i.set(0,p.bytes.length,p.pts,p.flags);muxer.writeSampleData(p.track,ByteBuffer.wrap(p.bytes),i);bytesWritten+=p.bytes.length;}
    final Runnable progress=new Runnable(){public void run(){if(!busy||stop)return;long secs=(System.currentTimeMillis()-startTime)/1000;
        String audioState=audioMode==3?"Bina audio":(System.currentTimeMillis()-levelAt<4000?"Awaaz aa rahi hai":"Awaaz silent - player ka audio check karo");
        status=String.format(Locale.US,"REC %02d:%02d:%02d | %s",secs/3600,(secs/60)%60,secs%60,audioState);
        getSystemService(NotificationManager.class).notify(21,notice(status));
        if(getExternalFilesDir(null)!=null&&getExternalFilesDir(null).getUsableSpace()<150L*1024*1024){stop=true;status="Storage low - save ho raha hai";}
        handler.postDelayed(this,1000);
    }};
    void release(){
        if(display!=null)try{display.release();}catch(Exception ignored){}
        if(projection!=null)try{projection.stop();}catch(Exception ignored){}
        for(AudioRecord r:new AudioRecord[]{playback,mic})if(r!=null){try{r.stop();}catch(Exception ignored){}r.release();}
        for(MediaCodec c:new MediaCodec[]{video,audio})if(c!=null){try{c.stop();}catch(Exception ignored){}try{c.release();}catch(Exception ignored){}}
        if(surface!=null)surface.release();if(muxer!=null)try{muxer.release();}catch(Exception ignored){}if(fd!=null)try{fd.close();}catch(Exception ignored){}
    }
    public void onDestroy(){stop=true;super.onDestroy();}
}
