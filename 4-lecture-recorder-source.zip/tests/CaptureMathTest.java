import com.lecturerecorder.app.CaptureMath;
public class CaptureMathTest {
 public static void main(String[] args){
   int[] a=CaptureMath.fit(1080,2400,1280);assert a[0]==576&&a[1]==1280;
   int[] b=CaptureMath.fit(2400,1080,1920);assert b[0]==1920&&b[1]==864;
   assert CaptureMath.mix((short)32000,(short)10000)==32767;
   assert CaptureMath.mix((short)-32000,(short)-10000)==-32768;
   assert CaptureMath.mix((short)100,(short)200)==200;
   assert CaptureMath.audioTime(48000,48000)==1000000;
   assert CaptureMath.audioTime(48000L*60*60*5,48000)==18000000000L;
   boolean bad=false;try{CaptureMath.fit(0,500,1280);}catch(IllegalArgumentException e){bad=true;}assert bad;
   System.out.println("8 CaptureMath checks passed");
 }
}
