package com.lecturerecorder.app;
public final class CaptureMath {
    public static int[] fit(int w,int h,int cap) {
        if(w<=0||h<=0) throw new IllegalArgumentException("Invalid screen size");
        double scale=Math.min(1.0,(double)cap/Math.max(w,h));
        return new int[]{Math.max(2,((int)(w*scale)/2)*2),Math.max(2,((int)(h*scale)/2)*2)};
    }
    public static short mix(short system,short mic) {
        return (short)Math.max(Short.MIN_VALUE,Math.min(Short.MAX_VALUE,(int)system+(int)mic/2));
    }
    public static short add(short a,short b) {
        return (short)Math.max(Short.MIN_VALUE,Math.min(Short.MAX_VALUE,(int)a+(int)b));
    }
    public static long audioTime(long frames,int rate) { return frames*1000000L/rate; }
}
